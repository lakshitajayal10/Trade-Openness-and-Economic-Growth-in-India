# ==============================================================================
# Trade Openness & Economic Growth in India (2000-2024)
# A Statistical Study using Simple & Multiple Linear Regression
#
# Authors: Lakshita Jayal, Radhika Gupta
# Data source: World Bank World Development Indicators
#   - GDP growth (annual %):        NY.GDP.MKTP.KD.ZG
#   - Trade (% of GDP):             NE.TRD.GNFS.ZS
# ==============================================================================

# ---- 1. Load data ------------------------------------------------------------
trade_openness_csv <- read.csv("data/india_trade_gdp_2000_2024.csv")
str(trade_openness_csv)

# ---- 2. Summary statistics ----------------------------------------------------
summary(trade_openness_csv)

# ---- 3. Correlation matrix -----------------------------------------------------
cor(trade_openness_csv[, c("GDP_Growth_Percent", "Trade_Openness_Percent_GDP", "Year")])

# ---- 4. Simple linear regression: GDP Growth ~ Trade Openness -----------------
model_simple <- lm(GDP_Growth_Percent ~ Trade_Openness_Percent_GDP, data = trade_openness_csv)
summary(model_simple)

# ---- 5. Multiple linear regression: GDP Growth ~ Trade Openness + Year --------
model_multiple <- lm(GDP_Growth_Percent ~ Trade_Openness_Percent_GDP + Year, data = trade_openness_csv)
summary(model_multiple)

# ---- 6. Visualizations ---------------------------------------------------------
dir.create("outputs", showWarnings = FALSE)

# 6a. Scatter plot with regression line
png("outputs/scatter_trade_vs_gdp.png", width = 1000, height = 700, res = 120)
plot(trade_openness_csv$Trade_Openness_Percent_GDP, trade_openness_csv$GDP_Growth_Percent,
     main = "Trade Openness vs GDP Growth",
     xlab = "Trade Openness (% of GDP)", ylab = "GDP Growth (%)",
     pch = 19, col = "blue")
abline(model_simple, col = "red", lwd = 2)
dev.off()

# 6b. Histograms
png("outputs/histograms.png", width = 1200, height = 600, res = 120)
par(mfrow = c(1, 2))
hist(trade_openness_csv$GDP_Growth_Percent, col = "grey80",
     main = "Histogram of GDP Growth", xlab = "GDP Growth (%)")
hist(trade_openness_csv$Trade_Openness_Percent_GDP, col = "lightgreen",
     main = "Histogram of Trade Openness", xlab = "Trade Openness (% of GDP)")
dev.off()

# 6c. Boxplots
png("outputs/boxplots.png", width = 1200, height = 600, res = 120)
par(mfrow = c(1, 2))
boxplot(trade_openness_csv$GDP_Growth_Percent, col = "orange",
        main = "Boxplot of GDP Growth", ylab = "GDP Growth (%)")
boxplot(trade_openness_csv$Trade_Openness_Percent_GDP, col = "pink",
        main = "Boxplot of Trade Openness", ylab = "Trade Openness (% of GDP)")
dev.off()

# ---- 7. Export console output for the README -----------------------------------
sink("outputs/regression_output.txt")
cat("SIMPLE REGRESSION\n")
print(summary(model_simple))
cat("\nMULTIPLE REGRESSION\n")
print(summary(model_multiple))
cat("\nCORRELATION MATRIX\n")
print(cor(trade_openness_csv[, c("GDP_Growth_Percent", "Trade_Openness_Percent_GDP", "Year")]))
cat("\nSUMMARY STATISTICS\n")
print(summary(trade_openness_csv))
sink()
